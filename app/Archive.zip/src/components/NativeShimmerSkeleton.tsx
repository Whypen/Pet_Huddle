// Reusable shimmer skeleton for native loading states.
//
// Renders a base muted rectangle with an animated highlight band that sweeps
// across it on a loop. Uses Reanimated worklets so the animation runs on the
// UI thread. When reduced motion is enabled, falls back to a static fill.
//
// Drop-in usage: replace any `<View style={styles.skeleton} />` placeholder
// with `<NativeShimmerSkeleton style={styles.skeleton} />`. The component
// owns the entire visual; do not pass children.

import { useEffect } from "react";
import { LinearGradient } from "expo-linear-gradient";
import { StyleSheet, type ViewStyle, type StyleProp } from "react-native";
import Animated, {
  Easing,
  useAnimatedStyle,
  useReducedMotion,
  useSharedValue,
  withRepeat,
  withTiming,
} from "react-native-reanimated";
import { huddleColors } from "../theme/huddleDesignTokens";

const SHIMMER_DURATION_MS = 1400;
const HIGHLIGHT_WIDTH_RATIO = 0.6;

type NativeShimmerSkeletonProps = {
  style?: StyleProp<ViewStyle>;
};

export function NativeShimmerSkeleton({ style }: NativeShimmerSkeletonProps) {
  const progress = useSharedValue(0);
  const reduceMotion = useReducedMotion();

  useEffect(() => {
    if (reduceMotion) {
      progress.value = 0;
      return;
    }
    progress.value = 0;
    progress.value = withRepeat(
      withTiming(1, { duration: SHIMMER_DURATION_MS, easing: Easing.inOut(Easing.ease) }),
      -1,
      false,
    );
  }, [progress, reduceMotion]);

  const highlightStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: `${(progress.value * 200) - 100}%` }],
  }));

  return (
    <Animated.View style={[styles.base, style]}>
      {!reduceMotion ? (
        <Animated.View style={[styles.highlightWrapper, highlightStyle]} pointerEvents="none">
          <LinearGradient
            colors={[
              "rgba(255,255,255,0)",
              "rgba(255,255,255,0.55)",
              "rgba(255,255,255,0)",
            ]}
            start={{ x: 0, y: 0.5 }}
            end={{ x: 1, y: 0.5 }}
            style={[StyleSheet.absoluteFillObject, { width: `${HIGHLIGHT_WIDTH_RATIO * 100}%` }]}
          />
        </Animated.View>
      ) : null}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  base: {
    overflow: "hidden",
    backgroundColor: huddleColors.mutedCanvas,
  },
  highlightWrapper: {
    ...StyleSheet.absoluteFillObject,
  },
});
