import { Feather } from "@expo/vector-icons";
import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import * as ImagePicker from "expo-image-picker";
import { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, Image, Modal, Pressable, ScrollView, StyleSheet, Text, View, type ImageStyle } from "react-native";
import { NativeFormTextField } from "../NativeFormField";
import {
  areNativeSocialUsersBlocked,
  cleanupNativeSocialStorageImages,
  reportNativeSocialUser,
  uploadNativeSocialImage,
  type NativeSocialAuthor,
  type NativeSocialComposerMedia,
} from "../../lib/nativeSocial";
import { createNativeProtectedActionError, getNativeProtectedActionResult, logNativeProtectedActionFailure, type NativeProtectedActionCleanupResult } from "../../lib/nativeStorageCleanup";
import {
  huddleColors,
  huddleLayout,
  huddleMapBroadcastFooter,
  huddleRadii,
  huddleSpacing,
  huddleType,
} from "../../theme/huddleDesignTokens";
import {
  NATIVE_SOCIAL_REPORT_CATEGORIES,
  NATIVE_SOCIAL_REPORT_COPY,
  NATIVE_SOCIAL_REPORT_MAX_ATTACHMENTS,
  NATIVE_SOCIAL_REPORT_SOURCE,
  NATIVE_SOCIAL_REPORT_SOURCE_ORIGIN,
  nativeSocialReportTokens,
  type NativeReportSource,
  type NativeReportSourceOrigin,
} from "./nativeSocialReportConfig";

type NativeSocialReportTarget = {
  author: NativeSocialAuthor;
  userId: string;
};

const toggleSetValue = (set: Set<string>, value: string) => {
  const next = new Set(set);
  if (next.has(value)) next.delete(value);
  else next.add(value);
  return next;
};

export function NativeSocialReportModal({
  accessToken,
  currentUserId,
  chatRoomId,
  onClose,
  onNotice,
  onSubmitFailure,
  onSubmitStart,
  onSubmitSuccess,
  open,
  source = NATIVE_SOCIAL_REPORT_SOURCE,
  sourceOrigin = NATIVE_SOCIAL_REPORT_SOURCE_ORIGIN,
  target,
}: {
  accessToken?: string | null;
  currentUserId: string | null;
  chatRoomId?: string | null;
  onClose: () => void;
  onNotice: (message: string) => void;
  onSubmitFailure?: () => Promise<void> | void;
  onSubmitStart?: () => Promise<void> | void;
  onSubmitSuccess?: () => Promise<void> | void;
  open: boolean;
  source?: NativeReportSource;
  sourceOrigin?: NativeReportSourceOrigin;
  target: NativeSocialReportTarget | null;
}) {
  const [categories, setCategories] = useState<Set<string>>(new Set());
  const [details, setDetails] = useState("");
  const [otherText, setOtherText] = useState("");
  const [uploads, setUploads] = useState<NativeSocialComposerMedia[]>([]);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!open) {
      setCategories(new Set());
      setDetails("");
      setOtherText("");
      setUploads([]);
    }
  }, [open]);

  useEffect(() => {
    if (!open || !currentUserId || !target?.userId) return;
    let active = true;
    void areNativeSocialUsersBlocked(currentUserId, target.userId, accessToken).then((blocked) => {
      if (!active || !blocked) return;
      onNotice(NATIVE_SOCIAL_REPORT_COPY.blocked);
      onClose();
    });
    return () => {
      active = false;
    };
  }, [currentUserId, onClose, onNotice, open, target?.userId]);

  const pickImages = useCallback(async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) return;
    const result = await ImagePicker.launchImageLibraryAsync({
      allowsMultipleSelection: true,
      mediaTypes: ["images"],
      orderedSelection: true,
      preferredAssetRepresentationMode: ImagePicker.UIImagePickerPreferredAssetRepresentationMode.Compatible,
      quality: 0.86,
      selectionLimit: Math.max(1, NATIVE_SOCIAL_REPORT_MAX_ATTACHMENTS - uploads.length),
    });
    if (result.canceled) return;
    const incoming: NativeSocialComposerMedia[] = result.assets.map((asset) => ({
      durationSeconds: null,
      height: asset.height,
      kind: "image",
      mimeType: asset.mimeType,
      name: asset.fileName,
      size: asset.fileSize,
      uri: asset.uri,
      width: asset.width,
    }));
    setUploads((current) => [...current, ...incoming].slice(0, NATIVE_SOCIAL_REPORT_MAX_ATTACHMENTS));
  }, [uploads.length]);

  const submit = useCallback(async () => {
    if (!currentUserId) {
      onNotice(NATIVE_SOCIAL_REPORT_COPY.missingAuth);
      return;
    }
    if (!target?.userId) {
      onNotice(NATIVE_SOCIAL_REPORT_COPY.missingTarget);
      return;
    }
    if (categories.size === 0 || submitting) {
      if (categories.size === 0) onNotice(NATIVE_SOCIAL_REPORT_COPY.selectReason);
      return;
    }
    setSubmitting(true);
    const uploadedAttachmentUrls: string[] = [];
    try {
      await onSubmitStart?.();
      const attachmentUrls: string[] = [];
      for (const media of uploads) {
        const uploadedUrl = await uploadNativeSocialImage(currentUserId, media, "report", accessToken);
        uploadedAttachmentUrls.push(uploadedUrl);
        attachmentUrls.push(uploadedUrl);
      }
      await reportNativeSocialUser({
        accessToken,
        attachmentUrls,
        categories: Array.from(categories),
        details: details.trim() || null,
        other: categories.has("Others") ? otherText.trim() : "",
        chatRoomId: chatRoomId ?? null,
        reporterId: currentUserId,
        source,
        sourceOrigin,
        targetName: target.author.displayName || target.author.socialId,
        targetUserId: target.userId,
      });
      await onSubmitSuccess?.();
      onNotice(NATIVE_SOCIAL_REPORT_COPY.success);
      onClose();
    } catch (error) {
      if (currentUserId && uploadedAttachmentUrls.length > 0) {
        const cleanupResult: NativeProtectedActionCleanupResult = await cleanupNativeSocialStorageImages(uploadedAttachmentUrls, currentUserId, accessToken, "social_report_orphan_upload").catch(() => "failed" as const);
        logNativeProtectedActionFailure("[native.socialReport] orphan_cleanup", createNativeProtectedActionError({
          ok: false,
          stage: getNativeProtectedActionResult(error)?.stage || "domain_save",
          originalError: getNativeProtectedActionResult(error)?.originalError || error,
          cleanupAttempted: true,
          cleanupResult,
        }));
      }
      logNativeProtectedActionFailure("[native.socialReport] submit_failed", error);
      await onSubmitFailure?.();
      onNotice(NATIVE_SOCIAL_REPORT_COPY.missingTarget);
    } finally {
      setSubmitting(false);
    }
  }, [accessToken, categories, chatRoomId, currentUserId, details, onClose, onNotice, onSubmitFailure, onSubmitStart, onSubmitSuccess, otherText, source, sourceOrigin, submitting, target, uploads]);

  return (
    <Modal animationType="slide" onRequestClose={onClose} transparent visible={open}>
      <View style={styles.modalBackdrop}>
        <Pressable accessibilityRole="button" onPress={onClose} style={StyleSheet.absoluteFill} />
        <View style={styles.sheet}>
          <View style={styles.dragHandle} />
          <View style={styles.sheetHeader}>
            <View style={styles.sheetTitleBlock}>
              <Text style={styles.sheetTitle}>{NATIVE_SOCIAL_REPORT_COPY.title}</Text>
              <Text style={styles.reportIntro}>{NATIVE_SOCIAL_REPORT_COPY.intro}</Text>
            </View>
            <Pressable accessibilityRole="button" onPress={onClose} style={({ pressed }) => [styles.sheetIconButton, pressed ? styles.pressed : null]}>
              <Feather color={huddleColors.iconMuted} name="x" size={22} />
            </Pressable>
          </View>
          <ScrollView contentContainerStyle={styles.sheetContent}>
            {NATIVE_SOCIAL_REPORT_CATEGORIES.map((category) => (
              <Pressable key={category} accessibilityRole="checkbox" accessibilityState={{ checked: categories.has(category) }} onPress={() => setCategories((current) => toggleSetValue(current, category))} style={({ pressed }) => [styles.reportCategoryRow, pressed ? styles.pressed : null]}>
                <View style={[styles.checkboxBox, categories.has(category) ? styles.checkboxBoxActive : null]}>{categories.has(category) ? <Feather color={huddleColors.onPrimary} name="check" size={14} /> : null}</View>
                <Text style={styles.reportCategoryText}>{category}</Text>
              </Pressable>
            ))}
            {categories.has("Others") ? (
              <NativeFormTextField accessibilityLabel={NATIVE_SOCIAL_REPORT_COPY.otherPlaceholder} label="" onChangeText={setOtherText} placeholder={NATIVE_SOCIAL_REPORT_COPY.otherPlaceholder} value={otherText} />
            ) : null}
            <NativeFormTextField accessibilityLabel={NATIVE_SOCIAL_REPORT_COPY.detailsLabel} label="" multiline onChangeText={setDetails} placeholder={NATIVE_SOCIAL_REPORT_COPY.addDetailsPlaceholder} value={details} />
            {uploads.length > 0 ? (
              <View style={styles.uploadGrid}>
                {uploads.map((upload, index) => (
                  <View key={`${upload.uri}-${index}`} style={styles.uploadPreview}>
                    <Image accessibilityLabel={`${NATIVE_SOCIAL_REPORT_COPY.uploadAltPrefix} ${index + 1}`} accessibilityIgnoresInvertColors source={{ uri: upload.uri }} style={styles.uploadPreviewImage as ImageStyle} />
                  </View>
                ))}
              </View>
            ) : null}
          </ScrollView>
          <View style={styles.reportFooterRow}>
            <Pressable accessibilityLabel={NATIVE_SOCIAL_REPORT_COPY.imagePickerLabel} accessibilityRole="button" onPress={pickImages} style={({ pressed }) => [styles.imageButton, pressed ? styles.pressed : null]}>
              <Feather color={huddleColors.mutedText} name="camera" size={16} />
            </Pressable>
            <Pressable accessibilityRole="button" disabled={submitting} onPress={submit} style={({ pressed }) => [styles.primaryButton, submitting ? styles.disabled : null, pressed ? styles.pressed : null]}>
              {submitting ? (
                <ActivityIndicator color={huddleColors.onPrimary} size="small" />
              ) : (
                <>
                  <MaterialCommunityIcons color={huddleColors.onPrimary} name="alert" size={20} />
                  <Text style={styles.primaryButtonText}>{NATIVE_SOCIAL_REPORT_COPY.submit}</Text>
                </>
              )}
            </Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  checkboxBox: {
    alignItems: "center",
    backgroundColor: huddleColors.canvas,
    borderColor: huddleColors.fieldBorderStrong,
    borderRadius: nativeSocialReportTokens.checkboxBorderRadius,
    borderWidth: 1,
    height: nativeSocialReportTokens.checkboxSize,
    justifyContent: "center",
    width: nativeSocialReportTokens.checkboxSize,
  },
  checkboxBoxActive: {
    backgroundColor: huddleColors.blue,
    borderColor: huddleColors.blue,
  },
  disabled: {
    opacity: 0.45,
  },
  dragHandle: {
    alignSelf: "center",
    backgroundColor: huddleColors.divider,
    borderRadius: huddleRadii.pill,
    height: huddleSpacing.x1,
    marginTop: huddleSpacing.x2,
    width: huddleSpacing.x7,
  },
  modalBackdrop: {
    backgroundColor: nativeSocialReportTokens.modalBackdropColor,
    flex: 1,
    justifyContent: "flex-end",
  },
  pressed: {
    opacity: 0.76,
  },
  primaryButton: {
    alignItems: "center",
    backgroundColor: huddleColors.validationRed,
    borderRadius: huddleMapBroadcastFooter.ctaRadius,
    flex: 1,
    flexDirection: "row",
    gap: huddleSpacing.x2,
    justifyContent: "center",
    minHeight: huddleMapBroadcastFooter.ctaHeight,
  },
  primaryButtonText: {
    color: huddleColors.onPrimary,
    fontFamily: "Urbanist-700",
    fontSize: huddleType.label,
    lineHeight: huddleType.labelLine,
  },
  reportCategoryRow: {
    alignItems: "center",
    flexDirection: "row",
    gap: nativeSocialReportTokens.categoryGap,
    minHeight: nativeSocialReportTokens.categoryMinHeight,
  },
  reportCategoryText: {
    color: nativeSocialReportTokens.categoryTextColor,
    flex: 1,
    fontFamily: nativeSocialReportTokens.categoryTextFamily,
    fontSize: nativeSocialReportTokens.categoryTextSize,
    lineHeight: nativeSocialReportTokens.categoryTextLineHeight,
  },
  reportIntro: {
    color: nativeSocialReportTokens.introColor,
    fontFamily: nativeSocialReportTokens.introFamily,
    fontSize: nativeSocialReportTokens.introSize,
    lineHeight: nativeSocialReportTokens.introLineHeight,
  },
  sheet: {
    backgroundColor: nativeSocialReportTokens.sheetBackground,
    borderTopLeftRadius: huddleRadii.modal,
    borderTopRightRadius: huddleRadii.modal,
    maxHeight: nativeSocialReportTokens.modalMaxHeight,
    overflow: "hidden",
    ...nativeSocialReportTokens.sheetShadow,
  },
  sheetContent: {
    gap: nativeSocialReportTokens.contentGap,
    padding: nativeSocialReportTokens.sheetContentPadding,
    paddingBottom: huddleSpacing.x3,
  },
  sheetHeader: {
    alignItems: "flex-start",
    borderBottomColor: huddleColors.divider,
    borderBottomWidth: StyleSheet.hairlineWidth,
    flexDirection: "row",
    minHeight: nativeSocialReportTokens.sheetHeaderMinHeight,
    paddingLeft: nativeSocialReportTokens.sheetHeaderPaddingLeft,
    paddingRight: nativeSocialReportTokens.sheetHeaderPaddingRight,
  },
  sheetIconButton: {
    alignItems: "center",
    borderRadius: huddleRadii.pill,
    height: huddleLayout.minTouch,
    justifyContent: "center",
    width: huddleLayout.minTouch,
  },
  sheetTitle: {
    color: nativeSocialReportTokens.titleColor,
    fontFamily: nativeSocialReportTokens.titleFamily,
    fontSize: nativeSocialReportTokens.titleSize,
    lineHeight: nativeSocialReportTokens.titleLineHeight,
  },
  sheetTitleBlock: {
    flex: 1,
    gap: huddleSpacing.x1,
    paddingVertical: huddleSpacing.x2,
  },
  reportFooterRow: {
    alignItems: "center",
    flexDirection: "row",
    gap: huddleMapBroadcastFooter.gap,
    paddingBottom: huddleMapBroadcastFooter.bottomPadding,
    paddingHorizontal: huddleMapBroadcastFooter.horizontalPadding,
    paddingTop: huddleMapBroadcastFooter.topPadding,
  },
  imageButton: {
    alignItems: "center",
    borderColor: huddleMapBroadcastFooter.cameraButtonBorderColor,
    borderRadius: huddleMapBroadcastFooter.cameraButtonSize / 2,
    borderWidth: 1,
    backgroundColor: huddleMapBroadcastFooter.cameraButtonBackground,
    height: huddleMapBroadcastFooter.cameraButtonSize,
    justifyContent: "center",
    width: huddleMapBroadcastFooter.cameraButtonSize,
  },
  uploadGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: nativeSocialReportTokens.attachmentGridGap,
    marginTop: huddleSpacing.x3,
  },
  uploadPreview: {
    backgroundColor: huddleColors.mutedCanvas,
    borderRadius: nativeSocialReportTokens.attachmentRadius,
    height: nativeSocialReportTokens.attachmentPreviewSize,
    overflow: "hidden",
    width: nativeSocialReportTokens.attachmentPreviewSize,
  },
  uploadPreviewImage: {
    height: "100%",
    width: "100%",
  },
});
