import { useEffect } from "react";
import { StyleSheet, Text, View } from "react-native";
import { huddleColors, huddleSpacing, huddleType } from "../../theme/huddleDesignTokens";

type NativeStripeConnectOnboardingProps = {
  accountId?: string | null;
  userId?: string | null;
  visible?: boolean;
  onReadyStateChange?: (ready: boolean) => void;
  onExit?: () => void;
  onError?: (message: string) => void;
};

export function NativeStripeConnectOnboarding({ visible = true, onReadyStateChange }: NativeStripeConnectOnboardingProps) {
  useEffect(() => {
    onReadyStateChange?.(false);
  }, [onReadyStateChange]);

  if (!visible) return null;
  return (
    <View style={styles.wrap}>
      <Text style={styles.title}>Payout setup is temporarily unavailable.</Text>
      <Text style={styles.body}>We’ll reopen this after the native app recovery is complete.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    padding: huddleSpacing.x4,
    gap: huddleSpacing.x2,
  },
  title: {
    fontFamily: "Urbanist-700",
    fontSize: huddleType.label,
    lineHeight: huddleType.labelLine,
    color: huddleColors.text,
  },
  body: {
    fontFamily: "Urbanist-500",
    fontSize: huddleType.helper,
    lineHeight: huddleType.helperLine,
    color: huddleColors.subtext,
  },
});
