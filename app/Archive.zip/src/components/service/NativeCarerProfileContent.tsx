import { Feather } from "@expo/vector-icons";
import { useEffect, useMemo, useState } from "react";
import { Alert, Pressable, StyleSheet, Text, View } from "react-native";
import {
  formatCarerTime,
  SKILLS_GROUP_B,
  PROOF_CONFIG,
  type NativeCarerProfileViewData,
} from "../../lib/nativeCarerProfile";
import {
  huddleButtons,
  huddleColors,
  huddlePolaroid,
  huddleRadii,
  huddleShadows,
  huddleSpacing,
  huddleType,
} from "../../theme/huddleDesignTokens";
import { NativePolaroidCard, nativePolaroidStyles, type NativePolaroidBadge } from "../NativePolaroidCard";
import { NativeServiceProfileImage } from "./NativeServiceProfileImage";

type NativeCarerProfileContentProps = {
  provider: NativeCarerProfileViewData;
  canRequestService?: boolean;
  onRequestService?: () => void;
  showRequestAction?: boolean;
};

const serviceLabel = (provider: NativeCarerProfileViewData, value: string) =>
  value === "Others" && provider.servicesOther.trim() ? provider.servicesOther.trim() : value;

const keepServiceWordsTogether = (value: string) =>
  value.replace(/-/g, "\u2011").replace(/ /g, "\u00A0");

const hasCertifiedSkill = (provider: NativeCarerProfileViewData) =>
  provider.skills.some((skill) => (SKILLS_GROUP_B as readonly string[]).includes(skill));

const STORY_COLLAPSE_THRESHOLD = 160;

export function NativeCarerProfileContent({
  provider,
  canRequestService = true,
  onRequestService,
  showRequestAction = false,
}: NativeCarerProfileContentProps) {
  const [heroIndex, setHeroIndex] = useState(0);
  const [storyExpanded, setStoryExpanded] = useState(false);
  const [failedSlideUrls, setFailedSlideUrls] = useState<string[]>([]);

  const slides = useMemo(() => {
    const next: string[] = [];
    if (provider.avatarUrl) next.push(provider.avatarUrl);
    provider.socialAlbumUrls.forEach((url) => {
      if (url && !next.includes(url)) next.push(url);
    });
    return next;
  }, [provider.avatarUrl, provider.socialAlbumUrls]);

  const visibleSlides = useMemo(
    () => slides.filter((url) => !failedSlideUrls.includes(url)),
    [failedSlideUrls, slides],
  );

  useEffect(() => {
    setHeroIndex(0);
    setFailedSlideUrls([]);
  }, [slides]);

  const sortedSkills = useMemo(
    () => [...provider.skills].sort((a, b) => {
      const aCertified = (SKILLS_GROUP_B as readonly string[]).includes(a) ? 0 : 1;
      const bCertified = (SKILLS_GROUP_B as readonly string[]).includes(b) ? 0 : 1;
      return aCertified - bCertified;
    }),
    [provider.skills],
  );

  const serviceCaptions = provider.servicesOffered.map((service) => keepServiceWordsTogether(serviceLabel(provider, service)));
  const servicesAll = serviceCaptions.join(" · ");
  const availabilityDaysText = provider.days.length === 7 ? "Every day" : provider.days.map((day) => day.slice(0, 3)).join(", ");
  const availabilityTimeText = provider.timeBlocks.includes("Anytime")
    ? "Anytime"
    : provider.otherTimeFrom && provider.otherTimeTo
      ? `${formatCarerTime(provider.otherTimeFrom)} - ${formatCarerTime(provider.otherTimeTo)}`
      : "";

  const goToSlide = (direction: -1 | 1) => {
    if (visibleSlides.length <= 1) return;
    setHeroIndex((current) => (current + direction + visibleSlides.length) % visibleSlides.length);
  };

  const polaroidBadges: NativePolaroidBadge[] = [];
  if (provider.hasCar) {
    polaroidBadges.push({ color: huddleColors.onPrimary, name: "truck", style: nativePolaroidStyles.badgePrimary });
  }
  if (hasCertifiedSkill(provider)) {
    polaroidBadges.push({ color: huddleColors.onPrimary, name: "check-circle", style: nativePolaroidStyles.badgeSuccess });
  }
  if (provider.emergencyReadiness === true) {
    polaroidBadges.push({ color: huddleColors.onPrimary, name: "zap", style: nativePolaroidStyles.badgeEmergency });
  }

  return (
    <View style={styles.container}>
      <View style={styles.polaroidOuter}>
        <NativePolaroidCard
          badges={polaroidBadges}
          captionPrimary={provider.displayName || "Pet Carer"}
          captionSecondary={serviceCaptions.length > 0 ? (
            <View style={nativePolaroidStyles.captionSecondaryWrapDetail}>
              {serviceCaptions.map((service, index) => (
                <Text key={`${service}:${index}`} style={nativePolaroidStyles.captionSecondaryTokenDetail}>
                  {index > 0 ? " · " : ""}{service}
                </Text>
              ))}
            </View>
          ) : null}
          photo={(
            <>
              {visibleSlides.length > 0 ? (
                <NativeServiceProfileImage
                  accessibilityIgnoresInvertColors
                  onError={() => {
                    const failedUrl = visibleSlides[Math.min(heroIndex, visibleSlides.length - 1)];
                    if (failedUrl) setFailedSlideUrls((current) => current.includes(failedUrl) ? current : [...current, failedUrl]);
                  }}
                  resizeMode="cover"
                  uri={visibleSlides[Math.min(heroIndex, visibleSlides.length - 1)]}
                  style={nativePolaroidStyles.photo}
                />
              ) : (
                <View style={nativePolaroidStyles.photoPlaceholder}>
                  <Feather color={huddleColors.iconSubtle} name="image" size={34} />
                </View>
              )}
            </>
          )}
          photoOverlay={(
            <>
              {visibleSlides.length > 1 ? (
                <>
                  <Pressable accessibilityLabel="Previous" onPress={() => goToSlide(-1)} style={({ pressed }) => [styles.heroArrow, styles.heroArrowLeft, pressed ? styles.pressed : null]}>
                    <Feather color={huddleColors.text} name="chevron-left" size={20} />
                  </Pressable>
                  <Pressable accessibilityLabel="Next" onPress={() => goToSlide(1)} style={({ pressed }) => [styles.heroArrow, styles.heroArrowRight, pressed ? styles.pressed : null]}>
                    <Feather color={huddleColors.text} name="chevron-right" size={20} />
                  </Pressable>
                  <View style={styles.dots}>
                    {visibleSlides.map((_, index) => (
                      <View key={index} style={[styles.dot, index === heroIndex ? styles.dotActive : null]} />
                    ))}
                  </View>
                </>
              ) : null}
            </>
          )}
          variant="detail"
        />
      </View>

      {provider.story.trim() ? (
        <View style={styles.storySection}>
          <Text style={styles.quoteOpen}>“</Text>
          <Text
            numberOfLines={!storyExpanded && provider.story.length > STORY_COLLAPSE_THRESHOLD ? 5 : undefined}
            style={styles.storyText}
          >
            {provider.story}
          </Text>
          {provider.story.length > STORY_COLLAPSE_THRESHOLD ? (
            <Pressable
              accessibilityRole="button"
              onPress={() => setStoryExpanded((current) => !current)}
              style={({ pressed }) => [styles.storyToggle, pressed ? styles.pressed : null]}
            >
              <Text style={styles.storyToggleText}>{storyExpanded ? "See less" : "Read more"}</Text>
            </Pressable>
          ) : null}
          <Text style={styles.quoteClose}>”</Text>
        </View>
      ) : null}

      {provider.rateRows.some((row) => row.services.length > 0 || row.price) ? (
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Text style={styles.sectionLabel}>Services</Text>
            {provider.petTypes.length > 0 ? (
              <Text style={styles.mutedText}>
                Works with {provider.petTypes.map((petType) => {
                  if (petType === "Dogs" && provider.dogSizes.length > 0) return `Dogs (${provider.dogSizes.join(", ")})`;
                  if (petType === "Others" && provider.petTypesOther) return provider.petTypesOther;
                  return petType;
                }).join(", ")}
              </Text>
            ) : null}
          </View>
          {provider.rateRows.filter((row) => row.services.length > 0 || row.price).map((row, index) => {
            const label = row.services.length > 0 ? row.services.map((service) => keepServiceWordsTogether(serviceLabel(provider, service))).join(" · ") : "All\u00A0services";
            const hasPrice = Boolean(row.price && row.rate && provider.currency);
            return (
              <View key={`${label}:${index}`} style={[styles.serviceRow, index === 0 ? styles.rowBorderTop : null]}>
                <Text style={styles.serviceLabel}>{label}</Text>
                {hasPrice ? (
                  <Text style={styles.servicePrice}>{provider.currency} {row.price} <Text style={styles.serviceUnit}>/ {row.rate.toLowerCase()}</Text></Text>
                ) : (
                  <Text style={styles.askPrice}>Ask for price</Text>
                )}
              </View>
            );
          })}
        </View>
      ) : null}

      {sortedSkills.length > 0 || availabilityDaysText || availabilityTimeText || provider.minNoticeValue || provider.emergencyReadiness === true || provider.locationStyles.length > 0 ? (
        <View style={styles.infoCard}>
          {sortedSkills.length > 0 ? (
            <View style={styles.infoSection}>
              <Text style={styles.sectionLabel}>Skills</Text>
              <View style={styles.skillWrap}>
                {sortedSkills.map((skill) => {
                  const certified = (SKILLS_GROUP_B as readonly string[]).includes(skill);
                  const proof = provider.proofMetadata[skill] ?? {};
                  const proofFields = PROOF_CONFIG[skill as keyof typeof PROOF_CONFIG]?.fields ?? [];
                  const credentialRows = proofFields
                    .map((field) => {
                      const value = String(proof[field.key] || "").trim();
                      return value ? `${field.label}: ${value}` : "";
                    })
                    .filter(Boolean);
                  const content = (
                    <>
                      {certified ? (
                        <Feather color={huddleColors.success} name="check-circle" size={16} />
                      ) : (
                        <View style={styles.skillDot} />
                      )}
                      <Text style={certified ? styles.certifiedSkillText : styles.skillText}>{skill}</Text>
                    </>
                  );
                  return certified && credentialRows.length > 0 ? (
                    <Pressable
                      accessibilityRole="button"
                      key={skill}
                      onPress={() => Alert.alert("Credentials", credentialRows.join("\n"))}
                      style={({ pressed }) => [styles.skillRow, pressed ? styles.pressed : null]}
                    >
                      {content}
                    </Pressable>
                  ) : (
                    <View key={skill} style={styles.skillRow}>
                      {content}
                    </View>
                  );
                })}
              </View>
            </View>
          ) : null}

          {availabilityDaysText || availabilityTimeText || provider.minNoticeValue || provider.emergencyReadiness === true ? (
            <View style={[styles.infoSection, sortedSkills.length > 0 ? styles.sectionBorderTop : null]}>
              <View style={styles.inlineInfoRow}>
                <Feather color={huddleColors.iconMuted} name="clock" size={16} />
                <View style={styles.inlineInfoCopy}>
                  {availabilityDaysText ? <Text style={styles.inlineInfoText}>{availabilityDaysText}</Text> : null}
                  {availabilityTimeText ? <Text style={styles.inlineInfoText}>{availabilityTimeText}</Text> : null}
                </View>
              </View>
              {provider.minNoticeValue ? (
                <Text style={styles.noticeText}>{provider.minNoticeValue} {provider.minNoticeUnit} notice</Text>
              ) : null}
              {provider.emergencyReadiness === true ? (
                <View style={styles.emergencyPill}>
                  <Feather color={huddleColors.success} name="check-circle" size={14} />
                  <Text style={styles.emergencyText}>Emergency ok</Text>
                </View>
              ) : null}
            </View>
          ) : null}

          {provider.locationStyles.length > 0 ? (
            <View style={[styles.infoSection, sortedSkills.length > 0 || availabilityDaysText || availabilityTimeText || provider.minNoticeValue || provider.emergencyReadiness === true ? styles.sectionBorderTop : null]}>
              <View style={styles.inlineInfoRow}>
                <Feather color={huddleColors.iconMuted} name="map-pin" size={16} />
                <Text style={styles.inlineInfoText}>
                  {provider.locationStyles.join(", ")}
                  {provider.areaName.trim() ? ` · ${provider.areaName.trim()}` : ""}
                </Text>
              </View>
            </View>
          ) : null}
        </View>
      ) : null}

      {showRequestAction ? (
        <Pressable
          accessibilityRole="button"
          disabled={!canRequestService}
          onPress={onRequestService}
          style={({ pressed }) => [styles.requestButton, pressed && canRequestService ? styles.pressed : null, !canRequestService ? styles.disabled : null]}
        >
          <Text style={styles.requestText}>{canRequestService ? "Request a Service" : "Verify identity to request"}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    gap: huddleSpacing.x4,
    paddingBottom: huddleSpacing.x4,
  },
  polaroidOuter: {
    paddingHorizontal: huddleSpacing.x3,
    paddingTop: huddleSpacing.x1,
  },
  heroArrow: {
    position: "absolute",
    top: "50%",
    width: 32,
    height: 32,
    marginTop: -16,
    borderRadius: huddleRadii.pill,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: huddleColors.glassOverlay,
  },
  heroArrowLeft: {
    left: huddleSpacing.x2,
  },
  heroArrowRight: {
    right: huddleSpacing.x2,
  },
  dots: {
    position: "absolute",
    top: huddleSpacing.x3,
    right: huddleSpacing.x3,
    flexDirection: "row",
    gap: 6,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: huddleRadii.pill,
    backgroundColor: huddleColors.glassControl,
  },
  dotActive: {
    width: 20,
    backgroundColor: huddleColors.canvas,
  },
  storySection: {
    paddingHorizontal: huddleSpacing.x6,
    paddingVertical: huddleSpacing.x2,
  },
  quoteOpen: {
    fontFamily: "Georgia",
    fontSize: 44,
    lineHeight: 44,
    color: huddleColors.sectionDividerStrong,
    marginBottom: -14,
  },
  quoteClose: {
    fontFamily: "Georgia",
    fontSize: 44,
    lineHeight: 44,
    color: huddleColors.sectionDividerStrong,
    textAlign: "right",
    marginTop: -8,
  },
  storyText: {
    fontFamily: "Urbanist-500",
    fontSize: huddleType.body,
    lineHeight: 28,
    color: huddleColors.text,
  },
  storyToggle: {
    alignSelf: "flex-start",
    marginTop: huddleSpacing.x1,
  },
  storyToggleText: {
    fontFamily: "Urbanist-600",
    fontSize: huddleType.label,
    lineHeight: huddleType.labelLine,
    color: huddleColors.mutedText,
  },
  card: {
    overflow: "hidden",
    borderRadius: huddleRadii.card,
    backgroundColor: huddleColors.canvas,
    borderWidth: 1,
    borderColor: huddleColors.cardBorderSoft,
    ...huddleShadows.glassElevation1,
  },
  cardHeader: {
    paddingHorizontal: huddleSpacing.x5,
    paddingTop: huddleSpacing.x5,
    paddingBottom: huddleSpacing.x3,
  },
  sectionLabel: {
    fontFamily: "Urbanist-700",
    fontSize: huddleType.label,
    lineHeight: huddleType.labelLine,
    letterSpacing: 1,
    textTransform: "uppercase",
    color: huddleColors.mutedText,
    marginBottom: huddleSpacing.x2,
  },
  mutedText: {
    fontFamily: "Urbanist-500",
    fontSize: huddleType.body,
    lineHeight: huddleType.body + 6,
    color: huddleColors.text,
  },
  serviceRow: {
    minHeight: 56,
    paddingHorizontal: huddleSpacing.x5,
    paddingVertical: huddleSpacing.x4,
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    gap: huddleSpacing.x4,
    borderTopWidth: 1,
    borderTopColor: huddleColors.sectionDividerStrong,
  },
  rowBorderTop: {
    borderTopWidth: 1,
  },
  serviceLabel: {
    flex: 1,
    minWidth: 0,
    fontFamily: "Urbanist-700",
    fontSize: huddleType.body,
    lineHeight: huddleType.body + 6,
    color: huddleColors.text,
  },
  servicePrice: {
    width: 132,
    textAlign: "right",
    fontFamily: "Urbanist-700",
    fontSize: huddleType.body,
    lineHeight: huddleType.body + 6,
    color: huddleColors.text,
  },
  serviceUnit: {
    fontFamily: "Urbanist-500",
    fontSize: huddleType.body,
    color: huddleColors.text,
  },
  askPrice: {
    width: 132,
    textAlign: "right",
    fontFamily: "Urbanist-500",
    fontSize: huddleType.body,
    color: huddleColors.text,
    fontStyle: "italic",
  },
  infoCard: {
    overflow: "hidden",
    borderRadius: huddleRadii.card,
    borderWidth: 1,
    borderColor: huddleColors.fieldBorderSoft,
    backgroundColor: huddleColors.mutedCanvas,
  },
  infoSection: {
    paddingHorizontal: huddleSpacing.x5,
    paddingVertical: huddleSpacing.x5,
  },
  sectionBorderTop: {
    borderTopWidth: 1,
    borderTopColor: huddleColors.sectionDividerStrong,
  },
  skillWrap: {
    gap: huddleSpacing.x3,
    rowGap: huddleSpacing.x3,
  },
  skillRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: huddleSpacing.x2,
  },
  skillDot: {
    width: 6,
    height: 6,
    borderRadius: huddleRadii.pill,
    backgroundColor: huddleColors.iconSubtle,
  },
  skillText: {
    flex: 1,
    minWidth: 0,
    fontFamily: "Urbanist-500",
    fontSize: huddleType.body,
    lineHeight: huddleType.body + 6,
    color: huddleColors.text,
  },
  certifiedSkillText: {
    flex: 1,
    minWidth: 0,
    fontFamily: "Urbanist-500",
    fontSize: huddleType.body,
    lineHeight: huddleType.body + 6,
    color: huddleColors.text,
    textDecorationLine: "underline",
  },
  inlineInfoRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: huddleSpacing.x3,
  },
  inlineInfoCopy: {
    flex: 1,
    minWidth: 0,
    gap: huddleSpacing.x1,
  },
  inlineInfoText: {
    fontFamily: "Urbanist-500",
    fontSize: huddleType.body,
    lineHeight: huddleType.body + 6,
    color: huddleColors.text,
  },
  noticeText: {
    marginLeft: huddleSpacing.x4 + huddleSpacing.x3,
    marginTop: huddleSpacing.x2,
    fontFamily: "Urbanist-500",
    fontSize: huddleType.body,
    lineHeight: huddleType.body + 6,
    color: huddleColors.text,
  },
  emergencyPill: {
    flexDirection: "row",
    alignItems: "center",
    gap: huddleSpacing.x1,
    marginLeft: huddleSpacing.x4 + huddleSpacing.x3,
    marginTop: huddleSpacing.x2,
    alignSelf: "flex-start",
  },
  emergencyText: {
    fontFamily: "Urbanist-500",
    fontSize: huddleType.body,
    lineHeight: huddleType.body + 6,
    color: huddleColors.success,
  },
  requestButton: {
    ...huddleButtons.base,
    ...huddleButtons.primary,
  },
  requestText: {
    ...huddleButtons.label,
    color: huddleColors.onPrimary,
  },
  pressed: {
    opacity: 0.78,
  },
  disabled: {
    opacity: 0.55,
  },
});
