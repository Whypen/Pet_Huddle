import { useCallback, useState } from "react";
import {
  ActivityIndicator,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { KeyboardAvoidingView } from "react-native-keyboard-controller";
import Feather from "@expo/vector-icons/Feather";
import { NativeTurnstile } from "../components/NativeTurnstile";
import { supabaseUrl } from "../lib/supabase";
import { createNativeFunctionHeaders } from "../lib/nativeFunctionClient";
import { haptic } from "../lib/nativeHaptics";
import {
  huddleButtons,
  huddleColors,
  huddleFieldStates,
  huddleLayout,
  huddleRadii,
  huddleShadows,
  huddleSpacing,
  huddleType,
} from "../theme/huddleDesignTokens";

type SupportErrors = {
  message?: string;
  replyEmail?: string;
};

type SupportFocusedField = "subject" | "message" | "replyEmail" | null;

const supportReplyEmailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const turnstileSiteKey =
  process.env.EXPO_PUBLIC_TURNSTILE_SITE_KEY ||
  process.env.VITE_TURNSTILE_SITE_KEY ||
  "0x4AAAAAAC1AMILxX8-lFNmm";

export function NativeSupportScreen({ accountEmail, accessToken, onCancel }: { accountEmail?: string | null; accessToken?: string | null; onCancel?: () => void }) {
  const normalizedAccountEmail = String(accountEmail || "").trim();
  const normalizedAccessToken = String(accessToken || "").trim();
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [wantsReply, setWantsReply] = useState(Boolean(normalizedAccountEmail));
  const [replyEmail, setReplyEmail] = useState(normalizedAccountEmail);
  const [errors, setErrors] = useState<SupportErrors>({});
  const [focusedField, setFocusedField] = useState<SupportFocusedField>(null);
  const [turnstileToken, setTurnstileToken] = useState("");
  const [turnstileError, setTurnstileError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");
  const [ticketNumber, setTicketNumber] = useState<string | null>(null);

  const requiresReplyEmail = wantsReply;
  const canSubmit = Boolean(message.trim()) && Boolean(turnstileToken.trim()) && !submitting;

  const clearError = useCallback((field: keyof SupportErrors) => {
    setErrors((current) => {
      if (!current[field]) return current;
      const next = { ...current };
      delete next[field];
      return next;
    });
  }, []);

  const validateSupportForm = useCallback(() => {
    const nextErrors: SupportErrors = {};
    if (!message.trim()) {
      nextErrors.message = "Please tell us how we can help.";
    }
    if (requiresReplyEmail) {
      const trimmedEmail = replyEmail.trim();
      if (!trimmedEmail) {
        nextErrors.replyEmail = "Enter your email if you want a reply.";
      } else if (!supportReplyEmailPattern.test(trimmedEmail)) {
        nextErrors.replyEmail = "Enter a valid email address.";
      }
    }
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  }, [message, replyEmail, requiresReplyEmail]);

  const resetSupportForm = useCallback(() => {
    setSubject("");
    setMessage("");
    setWantsReply(Boolean(normalizedAccountEmail));
    setReplyEmail(normalizedAccountEmail);
    setErrors({});
    setFocusedField(null);
    setSubmitError("");
    setTicketNumber(null);
    setTurnstileToken("");
    setTurnstileError("");
  }, [normalizedAccountEmail]);

  const submitSupport = useCallback(async () => {
    if (submitting) return;
    setSubmitError("");
    if (!validateSupportForm()) {
      haptic.error();
      return;
    }
    if (!turnstileToken.trim()) {
      haptic.error();
      setTurnstileError(turnstileError || "Complete human verification first.");
      return;
    }

    setSubmitting(true);
    try {
      const response = await fetch(`${supabaseUrl}/functions/v1/submit-support-ticket`, {
        method: "POST",
        headers: createNativeFunctionHeaders(normalizedAccessToken),
        body: JSON.stringify({
          name: "Guest",
          email: wantsReply ? replyEmail.trim() : "noreply@huddle.pet",
          subject: subject.trim() || "Support Request",
          message: message.trim(),
          wants_reply: wantsReply,
          turnstile_token: turnstileToken.trim(),
        }),
      });
      const body = (await response.json().catch(() => null)) as { ticket_number?: string; error?: string; message?: string } | null;
      if (!response.ok) {
        throw new Error(body?.error || body?.message || `Support submit failed with HTTP ${response.status}.`);
      }
      haptic.success();
      setTicketNumber(body?.ticket_number || "received");
      setSubject("");
      setMessage("");
      setReplyEmail("");
      setWantsReply(false);
      setErrors({});
      setTurnstileToken("");
      setTurnstileError("");
    } catch (error) {
      haptic.error();
      setSubmitError(error instanceof Error ? error.message : "Couldn't send your message. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }, [message, normalizedAccessToken, replyEmail, subject, submitting, turnstileError, turnstileToken, validateSupportForm, wantsReply]);

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      style={styles.container}
    >
      <ScrollView
        bounces={false}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.panel}>
          {ticketNumber ? (
            <View style={styles.successBox}>
              <Text style={styles.title}>Message sent!</Text>
              <Text style={styles.successText}>Your ticket number is {ticketNumber}.</Text>
              <Pressable
                onPress={onCancel ?? resetSupportForm}
                style={({ pressed }) => [styles.primaryButton, pressed ? styles.pressed : null]}
              >
                <Text style={styles.primaryLabel}>Done</Text>
              </Pressable>
            </View>
          ) : (
            <>
              <Text style={styles.title}>Need help with huddle?</Text>

              <View style={styles.fieldGroup}>
                <Text style={styles.label}>Subject</Text>
                <TextInput
                  value={subject}
                  onFocus={() => setFocusedField("subject")}
                  onBlur={() => setFocusedField(null)}
                  onChangeText={(next) => {
                    setSubject(next);
                    setSubmitError("");
                  }}
                  placeholder="Subject (optional)"
                  placeholderTextColor={huddleColors.mutedText}
                  editable={!submitting}
                  style={[styles.field, focusedField === "subject" ? styles.fieldFocused : null]}
                />
              </View>

              <View style={styles.fieldGroup}>
                <Text style={styles.label}>Message</Text>
                <TextInput
                  value={message}
                  onFocus={() => setFocusedField("message")}
                  onChangeText={(next) => {
                    setMessage(next);
                    setSubmitError("");
                    if (next.trim()) clearError("message");
                  }}
                  onBlur={() => {
                    setFocusedField(null);
                    if (!message.trim()) setErrors((current) => ({ ...current, message: "Please tell us how we can help." }));
                  }}
                  placeholder="How can we help?"
                  placeholderTextColor={huddleColors.mutedText}
                  editable={!submitting}
                  multiline
                  scrollEnabled
                  textAlignVertical="top"
                  style={[
                    styles.field,
                    styles.textArea,
                    focusedField === "message" ? styles.fieldFocused : null,
                    errors.message ? styles.fieldError : null,
                  ]}
                />
                {errors.message ? <Text style={styles.errorText}>{errors.message}</Text> : null}
              </View>

              <Pressable
                disabled={submitting}
                onPress={() => {
                  const next = !wantsReply;
                  setWantsReply(next);
                  setSubmitError("");
                  if (!next) clearError("replyEmail");
                }}
                style={({ pressed }) => [styles.checkboxRow, pressed && !submitting ? styles.pressed : null]}
                accessibilityRole="checkbox"
                accessibilityState={{ checked: wantsReply }}
              >
                <View style={[styles.checkbox, wantsReply ? styles.checkboxChecked : null]}>
                  {wantsReply ? <Feather name="check" size={16} color={huddleColors.onPrimary} /> : null}
                </View>
                <Text style={styles.checkboxLabel}>You may follow up with me via email if needed.</Text>
              </Pressable>

              {requiresReplyEmail ? (
                <View style={styles.fieldGroup}>
                  <Text style={styles.label}>Email</Text>
                  <TextInput
                    value={replyEmail}
                    onFocus={() => setFocusedField("replyEmail")}
                    onChangeText={(next) => {
                      setReplyEmail(next);
                      setSubmitError("");
                      if (supportReplyEmailPattern.test(next.trim())) clearError("replyEmail");
                    }}
                    onBlur={() => {
                      setFocusedField(null);
                      const trimmed = replyEmail.trim();
                      if (!trimmed) {
                        setErrors((current) => ({ ...current, replyEmail: "Enter your email if you want a reply." }));
                      } else if (!supportReplyEmailPattern.test(trimmed)) {
                        setErrors((current) => ({ ...current, replyEmail: "Enter a valid email address." }));
                      }
                    }}
                    placeholder="name@email.com"
                    placeholderTextColor={huddleColors.mutedText}
                    autoCapitalize="none"
                    autoCorrect={false}
                    keyboardType="email-address"
                    editable={!submitting}
                    style={[
                      styles.field,
                      focusedField === "replyEmail" ? styles.fieldFocused : null,
                      errors.replyEmail ? styles.fieldError : null,
                    ]}
                  />
                  {errors.replyEmail ? <Text style={styles.errorText}>{errors.replyEmail}</Text> : null}
                </View>
              ) : null}

              <View style={styles.turnstileGroup}>
                <NativeTurnstile
                  action="support_ticket"
                  onError={setTurnstileError}
                  onToken={(token) => {
                    setTurnstileToken(token);
                    if (token) setTurnstileError("");
                  }}
                  siteKey={turnstileSiteKey}
                />
                {turnstileError ? <Text style={styles.errorText}>{turnstileError}</Text> : null}
              </View>
              {submitError ? <Text style={styles.errorText}>{submitError}</Text> : null}

              <View style={styles.buttonStack}>
                <Pressable
                  disabled={!canSubmit}
                  onPress={() => void submitSupport()}
                  style={({ pressed }) => [
                    styles.primaryButton,
                    pressed && canSubmit ? styles.pressed : null,
                    !canSubmit ? styles.disabled : null,
                  ]}
                >
                  {submitting ? <ActivityIndicator color={huddleColors.onPrimary} /> : <Text style={styles.primaryLabel}>Send</Text>}
                </Pressable>
                <Pressable
                  disabled={submitting}
                  onPress={onCancel ?? resetSupportForm}
                  style={({ pressed }) => [styles.secondaryButton, pressed && !submitting ? styles.pressed : null]}
                >
                  <Text style={styles.secondaryLabel}>Cancel</Text>
                </Pressable>
              </View>
            </>
          )}
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    width: "100%",
    backgroundColor: huddleColors.canvas,
  },
  scrollContent: {
    paddingHorizontal: huddleSpacing.x4,
    paddingTop: huddleSpacing.x5,
    paddingBottom: huddleSpacing.x5,
  },
  panel: {
    width: "100%",
    paddingHorizontal: huddleSpacing.x5,
    paddingTop: huddleSpacing.x5,
    paddingBottom: huddleSpacing.x5,
    gap: huddleSpacing.x4,
  },
  title: {
    fontFamily: "Urbanist-700",
    fontSize: huddleType.h4,
    lineHeight: huddleType.h4Line,
    color: huddleColors.text,
  },
  fieldGroup: {
    gap: huddleSpacing.x2,
  },
  label: {
    fontFamily: "Urbanist-700",
    fontSize: huddleType.label,
    lineHeight: huddleType.labelLine,
    color: huddleColors.text,
  },
  field: {
    minHeight: huddleLayout.fieldHeight,
    borderRadius: huddleRadii.field,
    borderWidth: 1,
    borderColor: "rgba(66, 73, 101, 0.08)",
    backgroundColor: "#FFFFFF",
    paddingHorizontal: huddleSpacing.x3,
    fontFamily: "Urbanist-500",
    fontSize: huddleType.body,
    lineHeight: 22,
    color: huddleColors.text,
    shadowColor: huddleColors.neutralShadow,
    shadowOpacity: 0.42,
    shadowRadius: 14,
    shadowOffset: { width: 5, height: 5 },
    elevation: 1,
  },
  fieldFocused: {
    ...huddleFieldStates.focused,
  },
  fieldError: {
    ...huddleFieldStates.error,
  },
  textArea: {
    height: 108,
    paddingTop: huddleSpacing.x3,
  },
  checkboxRow: {
    minHeight: huddleLayout.minTouch,
    flexDirection: "row",
    alignItems: "center",
    gap: huddleSpacing.x3,
  },
  checkbox: {
    width: 28,
    height: 28,
    borderWidth: 1,
    borderColor: "rgba(163,168,190,0.26)",
    borderRadius: 9,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
    shadowColor: huddleColors.neutralShadow,
    shadowOpacity: 0.85,
    shadowRadius: 13,
    shadowOffset: { width: 5, height: 5 },
    elevation: 1,
  },
  checkboxChecked: {
    borderColor: huddleColors.blue,
    backgroundColor: huddleColors.blue,
  },
  checkboxLabel: {
    flex: 1,
    fontFamily: "Urbanist-500",
    fontSize: 13,
    lineHeight: 18,
    color: huddleColors.text,
  },
  turnstileBox: {
    minHeight: 74,
    overflow: "hidden",
  },
  turnstileGroup: {
    gap: huddleSpacing.x2,
  },
  turnstileContainer: {
    height: 74,
    backgroundColor: "transparent",
  },
  turnstileWebView: {
    height: 74,
    backgroundColor: "transparent",
  },
  turnstileStatus: {
    position: "absolute",
    left: 2,
    bottom: 0,
    fontFamily: "Urbanist-500",
    fontSize: 12,
    lineHeight: 16,
    color: huddleColors.mutedText,
  },
  buttonStack: {
    gap: huddleSpacing.x3,
    paddingTop: huddleSpacing.x1,
  },
  primaryButton: {
    ...huddleButtons.base,
    ...huddleButtons.primary,
  },
  secondaryButton: {
    ...huddleButtons.base,
    ...huddleButtons.secondary,
  },
  primaryLabel: {
    ...huddleButtons.label,
    color: huddleColors.onPrimary,
  },
  secondaryLabel: {
    ...huddleButtons.label,
    color: huddleColors.text,
  },
  disabled: {
    ...huddleButtons.disabled,
  },
  pressed: {
    ...huddleButtons.pressed,
  },
  errorText: {
    fontFamily: "Urbanist-600",
    fontSize: huddleType.helper,
    lineHeight: 16,
    color: huddleColors.validationRed,
  },
  successBox: {
    gap: huddleSpacing.x3,
  },
  successText: {
    fontFamily: "Urbanist-500",
    fontSize: huddleType.label,
    lineHeight: huddleType.labelLine,
    color: huddleColors.text,
  },
});
