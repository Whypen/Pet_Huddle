export type NativeLegalSection = {
  title: string;
  body: string[];
  bullets?: string[];
};

export type NativeLegalPageContent = {
  path: string;
  title: string;
  effectiveDate: string;
  intro: string[];
  sections: NativeLegalSection[];
};

const privacy: NativeLegalPageContent = {
  path: "/privacy",
  title: "Privacy Policy",
  effectiveDate: "Effective date: 25 March 2026",
  intro: [
    "This Privacy Policy explains what personal information Huddle collects, why Huddle uses it, when Huddle shares it, how long Huddle keeps it, how Huddle transfers it, and what rights and choices users may have.",
  ],
  sections: [
    {
      title: "1. Scope",
      body: ["This Policy applies to Huddle's app, websites, legal pages, support channels, marketplace tools, social features, map features, payment flows, and related services."],
    },
    {
      title: "2. Information Huddle collects",
      body: ["Huddle collects account, profile, content, communications, payment, transaction, device, usage, location, trust and safety, and third-party information where relevant to the service."],
    },
    {
      title: "3. How Huddle uses information",
      body: ["Huddle uses information to operate accounts, provide product features, verify phone numbers, reduce fraud, process payments, personalise notifications and experience, improve the service, send allowed messages, comply with law, enforce terms, and protect users, pets, Huddle, and the public."],
    },
    {
      title: "4. Sharing, visibility, and retention",
      body: ["Huddle may share information with vendors, service providers, other users where a feature requires it, payment and app-store partners, analytics or measurement partners, legal authorities, or parties involved in business transactions. Huddle keeps information as long as reasonably needed for service, business, legal, fraud-prevention, dispute, and safety purposes."],
    },
    {
      title: "5. Location, automation, and choices",
      body: ["If location access is enabled, Huddle may use location data for discovery, maps, alerts, services, fraud prevention, and analytics. Huddle may also use automated tools for ranking, recommendations, spam control, moderation, and platform security. Depending on law, users may have rights to access, correct, delete, restrict, object to, receive, withdraw consent for, or opt out of certain uses of personal information."],
    },
  ],
};

const terms: NativeLegalPageContent = {
  path: "/terms",
  title: "Terms of Service",
  effectiveDate: "Effective date: 25 March 2026",
  intro: ["These Terms of Service govern access to and use of Huddle's app, websites, subscriptions, messaging, discovery features, map features, marketplace tools, payments, and related services."],
  sections: [
    { title: "1. Eligibility and accounts", body: ["Huddle is for users aged 13 and above. Some features, including Discover and stranger chat, are limited to users aged 16 and above. Users must provide accurate information, protect account credentials, and use only their own account unless Huddle clearly allows otherwise."] },
    { title: "2. What Huddle is", body: ["Huddle is a communication, community, and marketplace platform. Unless Huddle clearly states otherwise, Huddle does not directly provide pet-care services, veterinary services, emergency services, or professional advice."] },
    { title: "3. Acceptable use and content", body: ["Users must not break the law, impersonate anyone, misstate age or qualifications, harass or exploit anyone, post unlawful or harmful content, endanger people or pets, misuse payments or safety tools, bypass platform rules or bans, or interfere with the service. Users keep ownership of submitted content while granting Huddle a licence to host, store, copy, adapt, publish, display, distribute, promote, advertise, and otherwise use that content for operating, improving, protecting, and promoting Huddle, subject to law and the Privacy Policy."] },
    { title: "4. Payments, subscriptions, and virtual items", body: ["Some features require payment or a subscription. Subscriptions may renew automatically until cancelled, and purchases through Apple, Google, or another third party may need to be managed through that channel. Stars, credits, boosts, badges, or similar digital features are licensed, not sold, have no cash value, and may be changed or removed where allowed by law."] },
    { title: "5. Enforcement, disclaimers, and disputes", body: ["Huddle may investigate, suspend, restrict, remove content from, or terminate accounts or access if it believes a user broke these Terms or created risk. To the maximum extent allowed by law, Huddle is provided as is and as available. These Terms are governed by the laws of Hong Kong unless mandatory local law requires otherwise."] },
  ],
};

const communityGuidelines: NativeLegalPageContent = {
  path: "/community-guidelines",
  title: "Community Guidelines",
  effectiveDate: "Effective date: 25 March 2026",
  intro: ["Huddle is for pet people, not chaos. These rules apply across profiles, pet profiles, photos, bios, messages, reviews, comments, map features, bookings, listings, support interactions, and every other part of the service."],
  sections: [
    { title: "1. Be real", body: ["Do not impersonate anyone. Do not fake your age, identity, qualifications, service experience, or trust status. Do not create duplicate or evasion accounts."] },
    { title: "2. Protect people and pets", body: ["Do not threaten, harass, bully, stalk, exploit, or intimidate anyone. Do not post or send violent, hateful, sexually exploitative, abusive, or illegal content. Do not endanger people or pets."] },
    { title: "3. Respect privacy", body: ["Do not share someone else's private information without permission. Do not leak phone numbers, addresses, payment details, identity materials, or private conversations. Do not misuse location features to track or intimidate anyone."] },
    { title: "4. No fraud or scams", body: ["No phishing, charge abuse, fake reviews, fake bookings, fake claims, fraudulent listings, attempts to bypass payment, safety, moderation, evidence systems, or deceptive off-platform payment schemes."] },
    { title: "5. Enforcement", body: ["If users break these rules, Huddle may remove content, limit features, hold payments, revoke trust signals, suspend accounts, or permanently ban access."] },
  ],
};

const cookies: NativeLegalPageContent = {
  path: "/cookies",
  title: "Cookies and Similar Technologies Notice",
  effectiveDate: "Effective date: 25 March 2026",
  intro: ["Huddle may use cookies, SDKs, pixels, local storage, tags, and similar technologies on its websites and, where relevant, in its app and related services."],
  sections: [
    { title: "1. Why Huddle uses these tools", body: ["Huddle may use these technologies to keep the service secure and working, remember settings and preferences, measure usage and performance, and support analytics, recommendations, advertising, and personalisation."] },
    { title: "2. Choices", body: ["Depending on the technology and where a user lives, choices may be available through browser settings, device settings, app permissions, cookie banners, privacy controls, or opt-out tools. Where consent is required by law before non-essential technologies are used, Huddle will ask for it."] },
    { title: "3. More information", body: ["For broader information about data use, see the Privacy Policy. For request routes and privacy controls, see Privacy Choices."] },
  ],
};

const nativePrivacyChoices: NativeLegalPageContent = {
  path: "/nativeprivacychoices",
  title: "Privacy Choices",
  effectiveDate: "Effective date: 25 March 2026",
  intro: [
    "This page explains where users can manage privacy choices in the app and how to reach Huddle for requests that cannot be completed in the app.",
  ],
  sections: [
    {
      title: "1. In-app choices",
      body: ["Where available, users can manage parts of their information directly in the app, including profile details, pet details, visibility settings, messaging preferences, notifications, location participation, and some account settings."],
    },
    {
      title: "2. Privacy and legal requests",
      body: ["For all privacy, legal, deletion, access, correction, complaint, and support requests, email support@huddle.pet."],
    },
    {
      title: "3. What to include",
      body: ["To help Huddle process a request safely, include the email address or phone number linked to the account, the type of request, enough detail for Huddle to understand the request, and any information reasonably needed to verify identity."],
    },
    {
      title: "4. How Huddle handles requests",
      body: ["Huddle may verify identity, ask for more detail, refuse or limit a request where allowed by law, retain information where needed for security, fraud prevention, disputes, tax, accounting, or legal compliance, and respond within the time required by law."],
    },
    {
      title: "5. Complaints",
      body: ["If a user has a privacy complaint, they should contact Huddle first using the privacy route above. Users may also have the right to lodge a complaint with the data protection authority in their country of residence."],
    },
  ],
};

const serviceProviderAgreement: NativeLegalPageContent = {
  path: "/service-provider-agreement",
  title: "Pet Care Service Provider Agreement",
  effectiveDate: "Effective date: 25 March 2026",
  intro: ["This Agreement applies to any user who applies, registers, is approved, or offers pet-care services through Huddle. In the product, these users may be called Pet Carers. In this Agreement, they are called Service Providers."],
  sections: [
    { title: "1. Huddle's role", body: ["Huddle is a technology platform. It helps users discover each other, communicate, and arrange pet-care services. Unless Huddle clearly states otherwise, Huddle does not provide the underlying pet-care service and does not supervise or control how a Service Provider performs it."] },
    { title: "2. Independent provider status", body: ["Service Providers act as independent service providers, not as Huddle's employees, workers, agents, partners, or joint venturers. Service Providers are responsible for their own taxes, licences, permits, insurance, and legal compliance."] },
    { title: "3. Eligibility, profile accuracy, and service standards", body: ["Service Providers must be at least 18 years old, keep accurate profiles and listings, complete required checks, and provide services with reasonable care, skill, honesty, professionalism, timely communication, and prompt incident disclosure."] },
    { title: "4. Fees, payouts, cancellations, and disputes", body: ["Huddle charges a 10% platform fee on the agreed service quote, deducted before payout. Payouts may depend on verification, settlement timing, fraud review, reserves, or dispute status. Service Providers must honour confirmed bookings unless they have a valid reason to cancel and must cooperate with complaint, refund, safety, or dispute reviews."] },
    { title: "5. Suspension and other terms", body: ["Huddle may reject, suspend, limit, remove, or permanently revoke a Service Provider's marketplace status or account if Huddle believes the provider breached policy or created safety, fraud, legal, quality, or reputational risk. The disclaimers, liability limits, indemnity provisions, governing law terms, dispute process, and enforcement rights in the Huddle Terms of Service also apply."] },
  ],
};

const bookingTerms: NativeLegalPageContent = {
  path: "/booking-terms",
  title: "Pet Care Service Booking Terms",
  effectiveDate: "Effective date: 25 March 2026",
  intro: ["These Pet Care Service Booking Terms apply when a user requests, books, pays for, or receives pet-care services through Huddle as a pet owner, pet service requester, or person making a booking."],
  sections: [
    { title: "1. Huddle's role", body: ["Huddle is a technology platform. Huddle helps users discover providers, communicate, and arrange pet-care services. Huddle is not the care provider, does not employ the provider, and does not control how the provider performs the service."] },
    { title: "2. Customer responsibilities", body: ["Customers must provide complete, accurate, and up-to-date booking information, including pet details, medication, allergies, illness, service date, address, access instructions, emergency contacts, and any other safety-relevant information. Customers confirm they are authorised to make care, access, and payment decisions for the pet in the booking."] },
    { title: "3. Provider review and scope", body: ["Before booking, customers are responsible for reviewing the provider's profile, services, pricing, availability, experience, qualifications, badges, and limitations. A provider is responsible only for the service actually agreed in the booking and any clearly documented follow-up instructions the provider accepts."] },
    { title: "4. Payments, cancellations, and disputes", body: ["Huddle charges a 10% platform service fee on the provider's quoted price. Once a booking is confirmed and paid, it is final and non-cancellable by the customer unless Huddle states otherwise, the provider cancels, Huddle cancels, or applicable law requires otherwise. Huddle may review, pause, cancel, refund, or limit bookings and payments where reasonably necessary for safety, fraud prevention, policy enforcement, legal compliance, complaints, disputes, or platform protection."] },
    { title: "5. Incidents, reviews, privacy, and disclaimers", body: ["Customers must report serious booking-related incidents to Huddle within 48 hours. Reviews must be honest and based on real experience. Booking details may be shared with the provider where needed to arrange and perform the service. Huddle does not guarantee any provider's conduct, availability, quality, safety, qualifications, or suitability."] },
  ],
};

export const NATIVE_LEGAL_PAGES: Record<string, NativeLegalPageContent> = {
  "/privacy": privacy,
  "/terms": terms,
  "/privacy-choices": nativePrivacyChoices,
  "/cookies": cookies,
  "/community-guidelines": communityGuidelines,
  "/service-provider-agreement": serviceProviderAgreement,
  "/booking-terms": bookingTerms,
};

export const getNativeLegalPage = (path: string) => NATIVE_LEGAL_PAGES[path] || null;
