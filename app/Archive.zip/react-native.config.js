module.exports = {
  dependencies: {},
};
