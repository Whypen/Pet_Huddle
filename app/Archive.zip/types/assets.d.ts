declare module "*.png" {
  const value: number;
  export default value;
}

declare module "*.jpg" {
  const value: number;
  export default value;
}

declare module "*.jpeg" {
  const value: number;
  export default value;
}

declare module "*.webp" {
  const value: number;
  export default value;
}

declare module "*.mp4" {
  const value: number;
  export default value;
}

declare module "*.ttf" {
  const value: number;
  export default value;
}

declare module "*.ttf" {
  const value: number;
  export default value;
}
